import qrcode from 'qrcode-terminal';

// Gerar QR code de teste
const testData = "https://telegram-scheduler-prod.eba-ccfz72tn.us-east-1.elasticbeanstalk.com/api/whatsapp/qr";

console.log("🔗 QR Code para acessar o endpoint do WhatsApp:");
console.log("Escaneie este QR code para acessar o endpoint:");

qrcode.generate(testData, { small: true });

console.log("\n📱 Ou acesse diretamente:");
console.log(testData); 