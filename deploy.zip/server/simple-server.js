import express from 'express';
// import { getWhatsAppBot } from './whatsapp/whatsappBot.js';
import qrcode from 'qrcode';

const app = express();
const port = process.env.PORT || 8080;

app.use(express.json());

// Health check simples
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    message: 'TelegramScheduler is running!',
    timestamp: new Date().toISOString(),
    port: port,
    telegramBot: !!process.env.TELEGRAM_BOT_TOKEN,
    database: !!process.env.DATABASE_URL
  });
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    message: 'TelegramScheduler API',
    version: '1.0.0',
    status: 'running',
    telegramBot: !!process.env.TELEGRAM_BOT_TOKEN,
    database: !!process.env.DATABASE_URL
  });
});

// Endpoint para obter QR code do WhatsApp (temporariamente desabilitado)
app.get('/api/whatsapp/qr', async (req, res) => {
  res.json({
    status: 'disabled',
    message: 'WhatsApp bot temporariamente desabilitado'
  });
});

// Endpoint para status do WhatsApp (temporariamente desabilitado)
app.get('/api/whatsapp/status', async (req, res) => {
  res.json({
    status: 'disabled',
    message: 'WhatsApp bot temporariamente desabilitado'
  });
});

// Start server
app.listen(port, () => {
  console.log(`🚀 Server running on port ${port}`);
  console.log(`📊 Health check: http://localhost:${port}/health`);
  console.log(`🌐 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🤖 Telegram Bot: ${process.env.TELEGRAM_BOT_TOKEN ? 'Configured' : 'Not configured'}`);
  console.log(`🗄️ Database: ${process.env.DATABASE_URL ? 'Configured' : 'Not configured'}`);
  console.log(`📱 WhatsApp QR: http://localhost:${port}/api/whatsapp/qr`);
});

export default app; 