/**
 * Bot Zelar - Versão avançada com interpretação inteligente de datas
 * Processamento avançado de eventos em português usando Luxon
 */

import { Telegraf } from 'telegraf';
import { parseUserDateTime, setUserTimezone, getUserTimezone, COMMON_TIMEZONES } from './utils/parseDate';
import { parseEventWithClaude } from '../utils/claudeParser';
import { DateTime, IANAZone } from 'luxon';

// =================== SISTEMA DE APRENDIZADO SIMPLES ===================
interface LearnedPattern {
  originalText: string;
  title: string;
  hour: number;
  minute: number;
  date: string;
  confidence: number;
  usageCount: number;
}

// Cache em memória para padrões aprendidos
const learnedPatterns: LearnedPattern[] = [];

/**
 * Salva um padrão bem-sucedido do Claude para uso futuro
 */
function savePatternForLearning(originalText: string, title: string, hour: number, minute: number, date: string): void {
  const existing = learnedPatterns.find(p => p.originalText === originalText);
  
  if (existing) {
    existing.usageCount++;
    existing.confidence = Math.min(existing.confidence + 0.1, 1.0);
  } else {
    learnedPatterns.push({
      originalText,
      title,
      hour,
      minute,
      date,
      confidence: 0.8,
      usageCount: 1
    });
  }
  
  console.log(`📚 Padrão aprendido: "${originalText}" → ${title} às ${hour}:${minute.toString().padStart(2, '0')}`);
}

/**
 * Verifica se existe um padrão similar aprendido
 */
function checkLearnedPatterns(userText: string): Event | null {
  const userTextLower = userText.toLowerCase();
  
  for (const pattern of learnedPatterns) {
    // Calcular similaridade simples
    const similarity = calculateSimpleSimilarity(userTextLower, pattern.originalText);
    
    if (similarity > 0.7 && pattern.confidence > 0.6) {
      console.log(`🎯 Padrão similar encontrado: "${pattern.originalText}" (similaridade: ${similarity.toFixed(2)})`);
      
      const eventDate = DateTime.fromObject({
        year: 2025,
        month: 5,
        day: 29,
        hour: pattern.hour,
        minute: pattern.minute
      }, { zone: 'America/Sao_Paulo' });
      
      return {
        title: pattern.title,
        startDate: eventDate.toISO() || eventDate.toString(),
        description: pattern.title,
        displayDate: eventDate.toFormat('EEEE, dd \'de\' MMMM \'às\' HH:mm', { locale: 'pt-BR' })
      };
    }
  }
  
  return null;
}

/**
 * Calcula similaridade simples entre dois textos
 */
function calculateSimpleSimilarity(text1: string, text2: string): number {
  const words1 = text1.split(' ').filter(w => w.length > 2);
  const words2 = text2.split(' ').filter(w => w.length > 2);
  
  let matches = 0;
  for (const word1 of words1) {
    if (words2.some(word2 => word1.includes(word2) || word2.includes(word1))) {
      matches++;
    }
  }
  
  return matches / Math.max(words1.length, words2.length);
}

let bot: Telegraf | null = null;
let isInitializing = false;

// =================== INÍCIO: FUNCIONALIDADE DE HORÁRIOS LOCAIS ===================
// Map para armazenar o fuso horário de cada usuário (ID do usuário -> fuso horário)
const userTimezones = new Map<number, string>();

// Regex para detectar padrões de horário em português
const TIME_PATTERNS = [
  { pattern: /às\s+(\d{1,2})\s*da\s+noite/gi, type: 'noite' },        // "às 7 da noite"
  { pattern: /às\s+(\d{1,2})\s*da\s+tarde/gi, type: 'tarde' },        // "às 3 da tarde" 
  { pattern: /às\s+(\d{1,2})\s*da\s+manhã/gi, type: 'manha' },        // "às 8 da manhã"
  { pattern: /às\s+(\d{1,2})\s*horas?/gi, type: 'neutral' },          // "às 19 horas"
  { pattern: /às\s+(\d{1,2})h/gi, type: 'neutral' },                  // "às 9h"
  { pattern: /às\s+(\d{1,2})\s*pm/gi, type: 'pm' },                   // "às 7pm"
  { pattern: /às\s+(\d{1,2})\s*am/gi, type: 'am' },                   // "às 9am"
];

/**
 * Interpreta horário local conforme o fuso do usuário
 */
function parseLocalTime(text: string, userId: number): { hour: number; minute: number; timezone: string } | null {
  const userTimezone = userTimezones.get(userId);
  
  if (!userTimezone) {
    return null; // Usuário precisa definir fuso primeiro
  }

  for (const { pattern, type } of TIME_PATTERNS) {
    pattern.lastIndex = 0; // Reset regex
    const match = pattern.exec(text);
    if (match) {
      let hour = parseInt(match[1]);
      const minute = 0; // Por simplicidade, assumindo minutos = 0
      
      // Ajustar horário baseado no contexto
      if (type === 'noite' && hour < 12) {
        hour += 12; // "7 da noite" = 19h
      } else if (type === 'tarde' && hour < 12) {
        hour += 12; // "3 da tarde" = 15h
      } else if (type === 'pm' && hour < 12) {
        hour += 12; // "7pm" = 19h
      }
      // "am" e "manhã" mantém o horário como está (0-11)
      
      return { hour, minute, timezone: userTimezone };
    }
  }
  
  return null;
}

/**
 * Formata horário no fuso do usuário
 */
function formatLocalTime(hour: number, minute: number, timezone: string): string {
  const now = DateTime.now().setZone(timezone);
  const targetTime = now.set({ hour, minute, second: 0, millisecond: 0 });
  const locationName = timezone.split('/')[1]?.replace('_', ' ') || timezone;
  
  return `${targetTime.toFormat('HH:mm')} no horário de ${locationName}`;
}
// =================== FIM: FUNCIONALIDADE DE HORÁRIOS LOCAIS ===================

interface Event {
  title: string;
  startDate: string; // ISO string for Google Calendar
  description: string;
  displayDate: string; // Formatted date for display
}

/**
 * Extrai título inteligente do evento focando na ação principal
 * CORREÇÃO: Agora extrai apenas o núcleo da tarefa, não a frase completa
 */
function extractEventTitle(text: string): string {
  const textLower = text.toLowerCase();
  
  // =================== CORREÇÃO: USAR CHRONO-NODE PARA DETECTAR DATA/HORA ===================
  
  // 1. CORREÇÃO: Remover completamente todas as expressões temporais da frase
  let cleanTitle = text;
  
  // =================== CORREÇÃO: LIMPEZA AVANÇADA DE TÍTULOS ===================
  
  // =================== CORREÇÃO: LIMPEZA MAIS AGRESSIVA E PRECISA ===================
  
  // CORREÇÃO COMPLETA: Limpeza robusta conforme solicitado
  const limparTitulo = (texto: string) =>
    texto
      .replace(/\b(marque|agende|coloque|anote|lembre|crie|faça|criar|fazer)\b/gi, '') // comandos primeiro
      .replace(/\b(me\s+lembre\s+de|lembre\s+me\s+de|me\s+lembrar\s+de)\b/gi, '') // "me lembre de"
      .replace(/\b(às|as)\s+\d{1,2}(:\d{2})?\s?(h|horas?|pm|am)?\b/gi, '') // horários "às 15", "às 15h"
      .replace(/\b(amanhã|amanha|hoje|ontem|segunda|terça|terca|quarta|quinta|sexta|sábado|sabado|domingo)(-feira)?\b/gi, '') // dias
      .replace(/\b(da\s+manhã|da\s+tarde|da\s+noite|de\s+manhã|de\s+tarde|de\s+noite)\b/gi, '') // períodos
      .replace(/\b\d{1,2}\/\d{1,2}(?:\/\d{2,4})?\b/gi, '') // datas dd/mm/yyyy
      .replace(/\s+/g, ' ') // múltiplos espaços
      .trim();
  
  cleanTitle = limparTitulo(cleanTitle);
  
  // Aplicar limpeza adicional se necessário
  const temporalPatterns = [
    /\b(próxima|proxima|que\s+vem)\b/gi,
    /\b(depois|antes|agora|já|ainda)\b/gi
  ];
  
  // Aplicar cada padrão sequencialmente
  for (const pattern of temporalPatterns) {
    const beforeClean = cleanTitle;
    cleanTitle = cleanTitle.replace(pattern, ' ');
    if (beforeClean !== cleanTitle) {
      console.log(`🧹 Removido "${beforeClean}" → "${cleanTitle}"`);
    }
  }
  
  // 3. Limpeza final mais rigorosa
  cleanTitle = cleanTitle
    .replace(/\s+/g, ' ') // múltiplos espaços → um espaço
    .replace(/^\s*(o|a|os|as|um|uma|no|na|em|de|da|do|às|as|para|pra)\s+/i, '') // artigos e preposições no início
    .replace(/\s+(no|na|em|de|da|do|às|as|para|pra)\s*$/i, '') // preposições no final
    .replace(/^\s*(e|com|sem|por)\s+/i, '') // conjunções no início
    .trim()
    .replace(/^./, char => char.toUpperCase()); // primeira letra maiúscula
  
  if (cleanTitle.length > 2) {
    console.log(`📝 Título limpo extraído: "${cleanTitle}" de "${text}"`);
    return capitalizeFirst(cleanTitle);
  }
  
  // 2. FALLBACK: Padrões específicos com contexto (ex: "reunião com João")
  const specificPatterns = [
    { regex: /reunião\s+com\s+([^,\s]+(?:\s+[^,\s]+)*)/i, format: (match: string) => `Reunião com ${match}` },
    { regex: /consulta\s+(?:com\s+)?(?:dr\.?\s+|dra\.?\s+)?([^,\s]+(?:\s+[^,\s]+)*)/i, format: (match: string) => `Consulta Dr. ${match}` },
    { regex: /dentista\s+(?:com\s+)?(?:dr\.?\s+|dra\.?\s+)?([^,\s]+(?:\s+[^,\s]+)*)/i, format: (match: string) => `Dentista Dr. ${match}` },
    { regex: /médico\s+(?:com\s+)?(?:dr\.?\s+|dra\.?\s+)?([^,\s]+(?:\s+[^,\s]+)*)/i, format: (match: string) => `Médico Dr. ${match}` },
    { regex: /aniversário\s+(?:do\s+|da\s+)?([^,\s]+(?:\s+[^,\s]+)*)/i, format: (match: string) => `Aniversário ${match}` },
    { regex: /festa\s+(?:do\s+|da\s+|de\s+)?([^,\s]+(?:\s+[^,\s]+)*)/i, format: (match: string) => `Festa ${match}` }
  ];
  
  for (const pattern of specificPatterns) {
    const match = textLower.match(pattern.regex);
    if (match && match[1]) {
      const result = pattern.format(match[1].trim());
      console.log(`📝 Título específico extraído: "${result}" de "${text}"`);
      return capitalizeFirst(result);
    }
  }
  
  // 2. Extrair após verbos de ação (removendo o verbo)
  const actionVerbs = [
    /(?:me\s+)?lembre?\s+de\s+(.+?)(?:\s+(?:hoje|amanhã|segunda|terça|quarta|quinta|sexta|sábado|domingo|às|na|no)|\s*$)/i,
    /(?:vou\s+|ir\s+)?fazer\s+(.+?)(?:\s+(?:hoje|amanhã|segunda|terça|quarta|quinta|sexta|sábado|domingo|às|na|no)|\s*$)/i,
    /agende?\s+(.+?)(?:\s+(?:hoje|amanhã|segunda|terça|quarta|quinta|sexta|sábado|domingo|às|na|no)|\s*$)/i,
    /marque?\s+(.+?)(?:\s+(?:hoje|amanhã|segunda|terça|quarta|quinta|sexta|sábado|domingo|às|na|no)|\s*$)/i,
    /criar?\s+(?:um\s+|uma\s+)?(.+?)(?:\s+(?:hoje|amanhã|segunda|terça|quarta|quinta|sexta|sábado|domingo|às|na|no)|\s*$)/i
  ];
  
  for (const verb of actionVerbs) {
    const match = text.match(verb);
    if (match && match[1]) {
      let extracted = match[1].trim();
      // Remover artigos desnecessários
      extracted = extracted.replace(/^(um|uma|o|a|os|as)\s+/i, '');
      console.log(`📝 Título extraído após verbo: "${extracted}" de "${text}"`);
      return capitalizeFirst(extracted);
    }
  }
  
  // 3. Palavras-chave diretas (como antes, mas mais refinado)
  const directKeywords = [
    'jantar', 'almoço', 'almoco', 'academia', 'trabalho', 'escola', 'aula',
    'compromisso', 'consulta', 'exame', 'reunião', 'reuniao', 'compras'
  ];
  
  for (const keyword of directKeywords) {
    if (textLower.includes(keyword)) {
      console.log(`📝 Palavra-chave direta encontrada: "${keyword}" de "${text}"`);
      return capitalizeFirst(keyword);
    }
  }
  
  // 4. Fallback: limpar e extrair núcleo da frase
  let cleaned = text
    // Remover verbos de ação no início
    .replace(/^(me\s+lembre\s+de\s+|agende\s+|marque\s+|criar?\s+|vou\s+|ir\s+)/i, '')
    // Remover artigos
    .replace(/^(um|uma|o|a|os|as)\s+/i, '')
    // Remover tempos
    .replace(/\b(amanhã|amanha|hoje|ontem)\b/gi, '')
    .replace(/\b(segunda|terça|terca|quarta|quinta|sexta|sábado|sabado|domingo)(-feira)?\b/gi, '')
    .replace(/\b(próxima|proxima|que vem|na|no)\b/gi, '')
    // Remover horários
    .replace(/\bàs?\s+\d{1,2}(:\d{2})?h?\b/gi, '')
    .replace(/\b\d{1,2}(am|pm)\b/gi, '')
    .replace(/\b(da manhã|da manha|da tarde|da noite)\b/gi, '')
    // Limpar espaços
    .replace(/\s+/g, ' ')
    .trim();
  
  console.log(`📝 Título limpo extraído: "${cleaned}" de "${text}"`);
  return capitalizeFirst(cleaned) || 'Evento';
}

/**
 * Capitaliza primeira letra de uma string
 */
function capitalizeFirst(str: string): string {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * Processa mensagem usando interpretação avançada de datas com detecção de fuso horário
 */
function processMessage(text: string, userId: string, languageCode?: string): Event | null {
  console.log(`🔍 Processando com detecção de fuso: "${text}"`);
  
  // Usar nossa função avançada de interpretação de datas com fuso do usuário
  const result = parseUserDateTime(text, userId, languageCode);
  
  if (!result) {
    console.log('❌ Não foi possível interpretar data/hora');
    return null;
  }
  
  const title = extractEventTitle(text);
  
  console.log(`📝 Título extraído: "${title}"`);
  console.log(`📅 Data interpretada: ${result.readable}`);
  
  return {
    title,
    startDate: result.iso,
    description: text,
    displayDate: result.readable
  };
}

/**
 * Gera links para calendários usando data ISO com fuso correto
 */
function generateLinks(event: Event) {
  // =================== CORREÇÃO 2: FORMATO GOOGLE CALENDAR CORRIGIDO ===================
  // Converter de volta para DateTime mantendo o fuso original
  const eventDateTime = DateTime.fromISO(event.startDate);
  const endDateTime = eventDateTime.plus({ hours: 1 });
  
  // Para Google Calendar: converter para UTC porque Google espera UTC no formato sem Z
  const startUTC = eventDateTime.toUTC();
  const endUTC = endDateTime.toUTC();
  
  const startFormatted = startUTC.toFormat('yyyyMMdd\'T\'HHmmss\'Z\'');
  const endFormatted = endUTC.toFormat('yyyyMMdd\'T\'HHmmss\'Z\'');
  
  // Para Outlook: usar ISO com fuso horário original
  const startISO = eventDateTime.toISO();
  const endISO = endDateTime.toISO();
  
  console.log(`🔗 Links gerados:`);
  console.log(`📅 Google UTC: ${startFormatted}/${endFormatted}`);
  console.log(`📅 Outlook: ${startISO} → ${endISO}`);
  
  const google = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(event.title)}&dates=${startFormatted}/${endFormatted}`;
  const outlook = `https://outlook.live.com/calendar/0/deeplink/compose?subject=${encodeURIComponent(event.title)}&startdt=${startISO}&enddt=${endISO}`;
  
  return { google, outlook };
}

/**
 * Iniciar bot
 */
export async function startZelarBot(): Promise<boolean> {
  try {
    // Prevenir múltiplas inicializações simultâneas
    if (isInitializing) {
      console.log('⚠️ Bot já está sendo inicializado...');
      return false;
    }
    
    isInitializing = true;
    
    // =================== CORREÇÃO: PREVENÇÃO DE MÚLTIPLAS INSTÂNCIAS ===================
    if (bot) {
      console.log('🔄 Parando instância anterior do bot...');
      await stopZelarBot();
    }

    // Verificar se existem outros processos ouvindo no bot
    console.log('🔍 Verificando conflitos...');

    if (!process.env.TELEGRAM_BOT_TOKEN) {
      throw new Error('TELEGRAM_BOT_TOKEN não encontrado');
    }

    console.log('🚀 Iniciando nova instância do bot...');
    console.log('📱 Token configurado:', process.env.TELEGRAM_BOT_TOKEN ? 'SIM' : 'NÃO');
    bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN);

    // Comando inicial
    bot.start((ctx) => {
      const userId = ctx.from?.id.toString() || 'unknown';
      const currentTimezone = getUserTimezone(userId, ctx.from?.language_code);
      
      ctx.reply(
        '🤖 *Zelar - Assistente Inteligente de Agendamentos*\n\n' +
        'Olá! Sou seu assistente para criar eventos com detecção automática de fuso horário!\n\n' +
        '📝 *Exemplos que entendo:*\n' +
        '• "jantar hoje às 19h"\n' +
        '• "reunião quarta às sete da noite"\n' +
        '• "19", "7 da noite"\n' +
        '• "consulta sexta que vem às 15h30"\n\n' +
        `🌍 *Seu fuso atual:* \`${currentTimezone}\`\n` +
        '⚙️ *Comandos úteis:*\n' +
        '• `/fuso` - configurar fuso horário\n' +
        '• `/interpretar` - testar datas\n\n' +
        '🧠 Digite seu compromisso! 🚀',
        { parse_mode: 'Markdown' }
      );
    });

    // Comando /fuso - configurar fuso horário
    bot.command('fuso', async (ctx) => {
      const message = ctx.message.text.replace('/fuso', '').trim();
      const userId = ctx.from?.id.toString() || 'unknown';
      
      if (!message) {
        const currentTimezone = getUserTimezone(userId, ctx.from?.language_code);
        const timezoneList = COMMON_TIMEZONES.slice(0, 6).map(tz => `• \`${tz}\``).join('\n');
        
        await ctx.reply(
          `🌍 *Configuração de Fuso Horário*\n\n` +
          `📍 *Seu fuso atual:* \`${currentTimezone}\`\n\n` +
          `💡 *Para alterar:* \`/fuso America/Sao_Paulo\`\n\n` +
          `📋 *Fusos comuns:*\n${timezoneList}`,
          { parse_mode: 'Markdown' }
        );
        return;
      }
      
      // =================== CORREÇÃO: TRATAMENTO ROBUSTO DE ERRO ===================
      try {
        const success = setUserTimezone(userId, message);
        
        if (success) {
          // Sincronizar com horários locais
          const numericUserId = ctx.from?.id || 0;
          userTimezones.set(numericUserId, message);
          
          const locationName = message.split('/')[1]?.replace('_', ' ') || message;
          await ctx.reply(
            `✅ *Fuso horário configurado!*\n\n` +
            `🌍 *Novo fuso:* ${locationName}\n` +
            `📍 *Código:* \`${message}\`\n\n` +
            `Agora quando você disser:\n` +
            `• "às 7 da noite" → será 19:00 no seu horário local\n` +
            `• "às 3 da tarde" → será 15:00 no seu horário local\n` +
            `• Todos os eventos usarão este fuso horário`,
            { parse_mode: 'Markdown' }
          );
        } else {
          await ctx.reply(
            `❌ *Fuso horário inválido*\n\n` +
            `💡 *Exemplos válidos:*\n` +
            `• \`America/Sao_Paulo\` (Brasil)\n` +
            `• \`America/Buenos_Aires\` (Argentina)\n` +
            `• \`Europe/Lisbon\` (Portugal)\n` +
            `• \`America/New_York\` (EUA)`,
            { parse_mode: 'Markdown' }
          );
        }
      } catch (error) {
        console.error('Erro ao configurar fuso horário:', error);
        await ctx.reply(
          `❌ *Erro interno*\n\n` +
          `Tente novamente ou use um fuso horário válido como \`America/Sao_Paulo\``
        );
      }
    });



    // Comando de teste para interpretação de datas
    bot.command('interpretar', async (ctx) => {
      const message = ctx.message.text.replace('/interpretar', '').trim();
      
      if (!message) {
        await ctx.reply(
          '💡 *Como usar:*\n\n' +
          '`/interpretar quarta às sete da noite`\n' +
          '`/interpretar sexta que vem às 19h`\n' +
          '`/interpretar 19` ou `/interpretar 7 da noite`\n\n' +
          'Digite qualquer data/hora!',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // =================== INÍCIO: INTEGRAÇÃO HORÁRIOS LOCAIS ===================
      const userId = ctx.from?.id || 0;
      
      // Primeiro tentar interpretar como horário local puro
      const localTime = parseLocalTime(message, userId);
      if (localTime) {
        const formattedTime = formatLocalTime(localTime.hour, localTime.minute, localTime.timezone);
        await ctx.reply(
          `✅ *Horário local interpretado!*\n\n` +
          `📝 *Você disse:* "${message}"\n\n` +
          `🕐 *Interpretei como:* ${formattedTime}\n\n` +
          `💡 *Para agendar:* Digite algo como "reunião sexta às 7 da noite"`
        );
        return;
      }
      
      // Se não conseguiu interpretar como horário local, verificar se precisa configurar fuso
      if (!userTimezones.has(userId) && (message.includes('às') || message.includes('da noite') || message.includes('da tarde'))) {
        await ctx.reply(
          `⚠️ *Configure seu fuso horário primeiro!*\n\n` +
          `💡 *Use:* \`/fuso America/Sao_Paulo\`\n\n` +
          `Depois você poderá usar horários como "às 7 da noite" que serão interpretados no seu fuso local.`,
          { parse_mode: 'Markdown' }
        );
        return;
      }
      // =================== FIM: INTEGRAÇÃO HORÁRIOS LOCAIS ===================

      const result = parseUserDateTime(message, userId.toString(), ctx.from?.language_code);
      
      if (result) {
        const currentTimezone = getUserTimezone(userId.toString(), ctx.from?.language_code);
        await ctx.reply(
          `✅ *Entendi perfeitamente!*\n\n` +
          `📝 *Você disse:* "${message}"\n\n` +
          `📅 *Interpretei como:*\n${result.readable}\n\n` +
          `🌍 *Fuso usado:* \`${currentTimezone}\``,
          { parse_mode: 'Markdown' }
        );
      } else {
        await ctx.reply(
          `❌ *Não consegui entender essa data/hora*\n\n` +
          `📝 *Você disse:* "${message}"\n\n` +
          `💡 *Tente algo como:*\n` +
          `• "hoje às 15h"\n` +
          `• "19" ou "7 da noite"\n` +
          `• "sexta às sete da noite"`
        );
      }
    });

    // Processar mensagens
    bot.on('text', async (ctx) => {
      try {
        const message = ctx.message.text;
        console.log(`📩 Mensagem recebida: "${message}" do usuário ${ctx.from?.username || ctx.from?.id}`);
        
        if (message.startsWith('/')) {
          console.log(`🔧 Comando detectado: ${message}`);
          return;
        }
        
        const userId = ctx.from?.id || 0;
        const userIdString = userId.toString();
        
        // =================== INÍCIO: VERIFICAÇÃO HORÁRIOS LOCAIS ===================
        // Verificar se a mensagem contém padrões que requerem fuso horário configurado
        const hasTimePattern = TIME_PATTERNS.some(({ pattern }) => {
          pattern.lastIndex = 0;
          return pattern.test(message);
        });
        
        // Se contém padrão de horário mas não tem fuso configurado, pedir configuração
        if (hasTimePattern && !userTimezones.has(userId)) {
          await ctx.reply(
            `⚠️ *Configure seu fuso horário primeiro!*\n\n` +
            `💡 *Use:* \`/fuso America/Sao_Paulo\`\n\n` +
            `Depois você poderá usar expressões como:\n` +
            `• "às 7 da noite" → 19:00 no seu horário local\n` +
            `• "às 3 da tarde" → 15:00 no seu horário local\n` +
            `• "às 9am" → 09:00 no seu horário local\n\n` +
            `📋 *Fusos comuns:*\n` +
            `• \`America/Sao_Paulo\` (Brasil)\n` +
            `• \`America/Buenos_Aires\` (Argentina)\n` +
            `• \`Europe/Lisbon\` (Portugal)`,
            { parse_mode: 'Markdown' }
          );
          return;
        }
        // =================== FIM: VERIFICAÇÃO HORÁRIOS LOCAIS ===================
        
        // =================== SISTEMA HÍBRIDO: CLAUDE + APRENDIZADO LOCAL ===================
        console.log(`🤖 Usando Claude Haiku para interpretar: "${message}"`);
        
        const userTimezone = getUserTimezone(userIdString, ctx.from?.language_code);
        const claudeResult = await parseEventWithClaude(message, userTimezone);
        
        let event;
        if (claudeResult.isValid) {
          // Usar resultado do Claude, mas limpar o nome do evento SEMPRE
          const eventDate = DateTime.fromObject({
            year: parseInt(claudeResult.date.split('-')[0]),
            month: parseInt(claudeResult.date.split('-')[1]),
            day: parseInt(claudeResult.date.split('-')[2]),
            hour: claudeResult.hour,
            minute: claudeResult.minute
          }, { zone: userTimezone });
          const isoString = eventDate.toISO();
          // NOVO: Sempre limpar o nome do evento
          const cleanTitle = extractEventTitle(message);
          event = {
            title: cleanTitle,
            startDate: isoString || eventDate.toString(),
            description: cleanTitle,
            displayDate: eventDate.toFormat('EEEE, dd \'de\' MMMM \'às\' HH:mm', { locale: 'pt-BR' })
          };
          // 🧠 APRENDIZADO: Salvar padrão bem-sucedido para melhorar parsing local
          savePatternForLearning(message.toLowerCase(), cleanTitle, claudeResult.hour, claudeResult.minute, claudeResult.date);
          console.log(`✅ Claude interpretou: ${cleanTitle} em ${claudeResult.date} às ${claudeResult.hour}:${claudeResult.minute}`);
        } else {
          // Fallback melhorado: verificar padrões aprendidos primeiro
          const learnedPattern = checkLearnedPatterns(message);
          if (learnedPattern) {
            console.log(`🎯 Usando padrão aprendido: ${learnedPattern.title}`);
            // Corrigir para usar o fuso do usuário
            const eventDate = DateTime.fromObject({
              year: parseInt(learnedPattern.startDate.split('-')[0]),
              month: parseInt(learnedPattern.startDate.split('-')[1]),
              day: parseInt(learnedPattern.startDate.split('-')[2]),
              hour: DateTime.fromISO(learnedPattern.startDate).hour,
              minute: DateTime.fromISO(learnedPattern.startDate).minute
            }, { zone: userTimezone });
            const isoString = eventDate.toISO();
            const cleanTitle = extractEventTitle(message);
            event = {
              title: cleanTitle,
              startDate: isoString || eventDate.toString(),
              description: cleanTitle,
              displayDate: eventDate.toFormat('EEEE, dd \'de\' MMMM \'às\' HH:mm', { locale: 'pt-BR' })
            };
          } else {
            // Usar método anterior como último recurso
            event = processMessage(message, userIdString, ctx.from?.language_code);
            // Corrigir para limpar o nome do evento
            if (event) {
              event.title = extractEventTitle(message);
              event.description = event.title;
            }
          }
        }
        
        if (!event) {
          await ctx.reply(
            '❌ *Não consegui entender a data/hora*\n\n' +
            '💡 *Tente algo como:*\n' +
            '• "jantar hoje às 19h"\n' +
            '• "reunião quarta às 15h"\n' +
            '• "consulta sexta que vem às 10 da manhã"\n\n' +
            '🔍 Use `/interpretar sua frase` para testar!\n' +
            '🌍 Use `/fuso` para configurar horários locais!',
            { parse_mode: 'Markdown' }
          );
          return;
        }
        
        const links = generateLinks(event);

        await ctx.reply(
          '✅ *Evento criado com sucesso!*\n\n' +
          `🎯 *${event.title}*\n` +
          `📅 ${event.displayDate}\n\n` +
          '📅 *Adicionar ao calendário:*',
          { 
            parse_mode: 'Markdown',
            reply_markup: {
              inline_keyboard: [
                [
                  { text: '📅 Google Calendar', url: links.google },
                  { text: '📅 Outlook', url: links.outlook }
                ]
              ]
            }
          }
        );

      } catch (error) {
        console.error('Erro:', error);
        await ctx.reply(
          '❌ *Erro ao processar sua mensagem*\n\n' +
          '💡 *Tente novamente com:*\n' +
          '• "jantar hoje às 19h"\n' +
          '• "reunião amanhã às 15h"\n\n' +
          'Ou use `/interpretar sua frase` para testar!'
        );
      }
    });

    // =================== CORREÇÃO: HANDLER PARA CALLBACK QUERY (BOTÕES INLINE) ===================
    bot.on('callback_query', async (ctx) => {
      try {
        if (!ctx.callbackQuery || !('data' in ctx.callbackQuery)) {
          await ctx.answerCbQuery('Dados inválidos');
          return;
        }

        const selectedTimezone = ctx.callbackQuery.data;
        const userId = ctx.from?.id.toString() || 'unknown';

        console.log(`🌍 Fuso selecionado: ${selectedTimezone} para usuário ${userId}`);

        // Validar fuso horário usando lista de fusos válidos
        const validTimezones = COMMON_TIMEZONES;
        if (!validTimezones.includes(selectedTimezone)) {
          await ctx.answerCbQuery('Fuso horário inválido');
          await ctx.reply('❌ Fuso horário inválido. Tente novamente.');
          return;
        }

        // Salvar fuso horário
        const success = setUserTimezone(userId, selectedTimezone);
        
        if (success) {
          // Sincronizar com Map local
          const numericUserId = ctx.from?.id || 0;
          userTimezones.set(numericUserId, selectedTimezone);
          
          const locationName = selectedTimezone.split('/')[1]?.replace('_', ' ') || selectedTimezone;
          
          await ctx.answerCbQuery(`Fuso configurado: ${locationName}`);
          await ctx.reply(
            `✅ *Fuso horário configurado!*\n\n` +
            `🌍 *Novo fuso:* ${locationName}\n` +
            `📍 *Código:* \`${selectedTimezone}\`\n\n` +
            `Agora quando você disser:\n` +
            `• "às 7 da noite" → será 19:00 no seu horário local\n` +
            `• "às 3 da tarde" → será 15:00 no seu horário local\n` +
            `• Todos os eventos usarão este fuso horário`,
            { parse_mode: 'Markdown' }
          );
        } else {
          await ctx.answerCbQuery('Erro ao salvar fuso');
          await ctx.reply('❌ Erro ao salvar fuso horário. Tente novamente.');
        }

      } catch (error) {
        console.error('Erro ao processar callback query:', error);
        await ctx.answerCbQuery('Erro interno');
        await ctx.reply('❌ Erro interno. Tente novamente.');
      }
    });

    // =================== DEFINIR COMANDOS OFICIAIS ===================
    // Limpar comandos desnecessários e definir apenas os úteis
    await bot.telegram.setMyCommands([
      { command: 'start', description: 'Iniciar o assistente' },
      { command: 'fuso', description: 'Configurar fuso horário' },
      { command: 'interpretar', description: 'Testar interpretação de datas' }
    ]);
    
    console.log('🚀 Iniciando bot via launch()...');
    await bot.launch();
    console.log('✅ Bot Zelar ativo com comandos limpos!');
    console.log('🔍 Bot aguardando mensagens...');
    
    // Adicionar um teste rápido
    try {
      const me = await bot.telegram.getMe();
      console.log(`✅ Bot identificado: @${me.username} (ID: ${me.id})`);
    } catch (error) {
      console.error('❌ Erro ao identificar bot:', error);
    }
    
    isInitializing = false;
    return true;

  } catch (error) {
    console.error('❌ Erro ao iniciar bot:', error);
    console.error('❌ Detalhes do erro:', (error as Error).message);
    isInitializing = false;
    return false;
  }
}

export async function stopZelarBot(): Promise<void> {
  if (bot) {
    console.log('🛑 Parando bot...');
    try {
      await bot.stop();
      await new Promise(resolve => setTimeout(resolve, 2000)); // Aguardar cleanup
    } catch (error) {
      console.log('⚠️ Erro ao parar bot:', (error as Error).message);
    }
    bot = null;
    isInitializing = false;
  }
}