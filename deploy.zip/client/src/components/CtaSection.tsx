import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { FaTelegram, FaWhatsapp } from "react-icons/fa";

export default function CtaSection() {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-primary to-secondary text-white">
      <div className="container mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Pronto para Simplificar seu Agendamento?</h2>
          <p className="text-xl text-white/90 mb-10 max-w-2xl mx-auto">
            Junte-se a milhares de usuários que estão economizando tempo e se organizando com o assistente de agenda IA do Zelar.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                asChild
                variant="default"
                size="lg"
                className="bg-white text-primary hover:bg-gray-100 font-semibold rounded-full px-8 py-4 text-lg"
              >
                <a 
                  href="https://t.me/zelar_assistente_bot" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center"
                >
                  <FaTelegram className="mr-3 text-xl" />
                  Usar no Telegram
                </a>
              </Button>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                asChild
                variant="default"
                size="lg"
                className="bg-green-500 hover:bg-green-600 text-white font-semibold rounded-full px-8 py-4 text-lg border-0"
              >
                <a 
                  href="https://wa.me/5511988049268?text=Ol%C3%A1%2C%20gostaria%20de%20usar%20o%20Zelar%20para%20agendar%20meus%20compromissos" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center"
                >
                  <FaWhatsapp className="mr-3 text-xl" />
                  Usar no WhatsApp
                </a>
              </Button>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
